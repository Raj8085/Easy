(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_TawkToChat_jsx_a29874b0._.js", {

"[project]/app/TawkToChat.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>TawkToChat)
});
// components/TawkToChat.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function TawkToChat() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TawkToChat.useEffect": ()=>{
            if (window.Tawk_API) return; // Prevent multiple injections
            const s1 = document.createElement("script");
            s1.src = "https://embed.tawk.to/67ee49dbb6b565190a1dbffa/1intd11mp"; // Replace with your ID
            s1.async = true;
            s1.charset = "UTF-8";
            s1.setAttribute("crossorigin", "*");
            document.body.appendChild(s1);
        }
    }["TawkToChat.useEffect"], []);
    return null;
} // import { useEffect } from 'react';
 // const TawkToChat = () => {
 //   useEffect(() => {
 //     var Tawk_API = window.Tawk_API || {};
 //     var Tawk_LoadStart = new Date();
 //     const s1 = document.createElement('script');
 //     s1.src = 'https://embed.tawk.to/67ee49dbb6b565190a1dbffa/1intd11mp';
 //     s1.async = true;
 //     s1.charset = 'UTF-8';
 //     s1.setAttribute('crossorigin', '*');
 //     document.body.appendChild(s1);
 //   }, []);
 //   return null; // No UI
 // };
 // export default TawkToChat;
_s(TawkToChat, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = TawkToChat;
var _c;
__turbopack_context__.k.register(_c, "TawkToChat");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_TawkToChat_jsx_a29874b0._.js.map