(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_f0e4c1a2.js",
  "chunks": [
    "static/chunks/[root of the server]__6f68ffb3._.css",
    "static/chunks/app_TawkToChat_jsx_a29874b0._.js"
  ],
  "source": "dynamic"
});
