export default function BotPage() {
    return (
        <div>
            <h1>Bot Content</h1>
            <p>This is what bots and crawlers see.</p>
        </div>
    );
}
