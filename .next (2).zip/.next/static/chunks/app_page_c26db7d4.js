(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_c26db7d4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_c26db7d4.js",
  "chunks": [
    "static/chunks/_57074d2d._.js"
  ],
  "source": "dynamic"
});
