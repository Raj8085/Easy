(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_4c5b00eb.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_4c5b00eb.js",
  "chunks": [
    "static/chunks/_48fea18c._.js"
  ],
  "source": "dynamic"
});
