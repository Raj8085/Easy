(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_f0e4c1a2.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_f0e4c1a2.js",
  "chunks": [
    "static/chunks/_48fea18c._.js"
  ],
  "source": "dynamic"
});
