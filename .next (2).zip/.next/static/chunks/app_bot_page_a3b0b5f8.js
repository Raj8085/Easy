(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_bot_page_a3b0b5f8.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_bot_page_a3b0b5f8.js",
  "chunks": [
    "static/chunks/_7bc7b8b0._.js"
  ],
  "source": "dynamic"
});
