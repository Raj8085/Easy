(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_248622f9.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_248622f9.js",
  "chunks": [
    "static/chunks/_48fea18c._.js"
  ],
  "source": "dynamic"
});
