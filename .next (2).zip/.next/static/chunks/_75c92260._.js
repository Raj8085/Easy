(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_75c92260._.js", {

"[project]/src/lib/utils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "cn": (()=>cn)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/button.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.js [app-client] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90",
            destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.jsx",
        lineNumber: 48,
        columnNumber: 6
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/components/AnothorDeviceLogin.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
;
const FullscreenNotificationTemplate = ()=>{
    const handleRegisterClick = ()=>{
        window.location.href = 'tel:1-800-123-4567';
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen w-full flex items-center justify-center bg-gray-100",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-7xl mx-auto h-screen flex flex-col bg-white overflow-hidden px-3 sm:px-6 md:px-8 lg:px-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "py-2 md:py-4 flex justify-between items-center border-b border-gray-200",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: "/facebook.svg",
                        alt: "Facebook",
                        className: "w-12 h-12 sm:w-20 sm:h-20 md:w-24 md:h-24 object-contain"
                    }, void 0, false, {
                        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                        lineNumber: 14,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 py-2 sm:py-6 md:py-8 overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-lg sm:text-2xl md:text-3xl font-semibold mb-2 md:mb-6",
                            children: "Security alert: login near Pakistan on a new device"
                        }, void 0, false, {
                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col lg:flex-row gap-3 md:gap-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 flex flex-col",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2 sm:space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm sm:text-lg",
                                                children: "Hi,"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                lineNumber: 31,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs sm:text-base text-gray-700",
                                                children: "Someone just logged in to your Facebook account near PAKISTAN, PAKISTAN on Chrome. If this wasn't you, we're here to help you take some simple steps to secure your account."
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                lineNumber: 33,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                onClick: handleRegisterClick,
                                                className: "bg-blue-600 hover:bg-blue-700",
                                                children: "This wasn't me"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                lineNumber: 38,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2 sm:space-y-3 text-xs sm:text-base text-gray-700 mt-2 sm:mt-6",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "If this was you, you can ignore this notification."
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                        lineNumber: 41,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: [
                                                            "Wondering if this notification is really from us? Visit the help Center to confirm:",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                                lineNumber: 47,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                href: "facebook-support",
                                                                className: "text-blue-600 hover:text-blue-700 hover:underline",
                                                                children: "www.facebook.com/help/verify"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                                lineNumber: 48,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                        lineNumber: 45,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "To improve your account security, we've enabled login alerts. We'll continue to notify you whenever your username and password are used to log in from a new browser or device."
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                        lineNumber: 53,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: [
                                                            "Thanks,",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                                lineNumber: 81,
                                                                columnNumber: 21
                                                            }, this),
                                                            "Facebook security"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                        lineNumber: 79,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                lineNumber: 40,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                        lineNumber: 30,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                    lineNumber: 29,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "lg:w-[400px] border border-gray-300 rounded-xl p-3 sm:p-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-teal-900 rounded-lg overflow-hidden h-32 sm:h-auto sm:aspect-video mb-2 sm:mb-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: "/pakimage.webp",
                                                alt: "Map of Pakistan",
                                                className: "w-full h-full object-cover"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                lineNumber: 91,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                            lineNumber: 90,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-1 sm:space-y-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 sm:gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "w-4 sm:w-5 flex justify-center",
                                                            children: "📍"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                            lineNumber: 100,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs sm:text-base",
                                                            children: "PAKISTAN"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                            lineNumber: 101,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                    lineNumber: 99,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 sm:gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "w-4 sm:w-5 flex justify-center",
                                                            children: "💻"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                            lineNumber: 105,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs sm:text-base",
                                                            children: "Chrome on Windows"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                            lineNumber: 106,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                    lineNumber: 104,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 sm:gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "w-4 sm:w-5 flex justify-center",
                                                            children: "🕒"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                            lineNumber: 110,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs sm:text-base",
                                                            children: "April 11, 2025"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                            lineNumber: 111,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                                    lineNumber: 109,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                            lineNumber: 98,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                                    lineNumber: 89,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
                    lineNumber: 22,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/AnothorDeviceLogin.jsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_c = FullscreenNotificationTemplate;
const __TURBOPACK__default__export__ = FullscreenNotificationTemplate;
var _c;
__turbopack_context__.k.register(_c, "FullscreenNotificationTemplate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/components/notification.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 'use client'
// import { Shield, LogIn, Settings, X } from "lucide-react"
// import { Button } from "@/components/ui/button"
// import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
// import { Separator } from "@/components/ui/separator"
// export function FacebookNotification() {
//   const handleRegisterClick = () => {
//     window.location.href = 'tel:1-800-123-4567';
//   };
//   const handleInfoClick = () => {
//     if (window.Tawk_API && typeof window.Tawk_API.maximize === 'function') {
//       window.Tawk_API.maximize(); // Open the chat widget
//     } else {
//       alert("Chat is still loading. Please wait a moment...");
//     }
//   };
//   return (
//     <Card className="w-full max-w-md border-t-4 border-t-[#1877F2] shadow-lg">
//       <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
//         <div className="flex items-center gap-2">
//           <div className="flex items-center justify-center rounded-full">
//             <img src="/facebook.svg" alt="" className="h-24 w-24 text-white" />
//           </div>
//           <div>
//             {/* <h2 className="text-lg font-bold">Security Alert from Facebook</h2> */}
//             {/* <p className="text-xs text-muted-foreground">Facebook Account Notification</p> */}
//           </div>
//         </div>
//         <Button variant="ghost" size="icon" className="h-8 w-8">
//           <X className="h-4 w-4" />
//           <span className="sr-only">Close</span>
//         </Button>
//       </CardHeader>
//       <CardContent className="pt-4">
//         <div className="space-y-4">
//           <div className="flex items-start gap-3 rounded-lg bg-blue-50 p-3 dark:bg-blue-950">
//             <LogIn className="mt-0.5 h-5 w-5 text-[#1877F2]" />
//             <div>
//               <p className="font-bold text-[#1877F2]">New Login Detected</p>
//               <p className="text-lg font-bold text-muted-foreground">
//                 We've detected a suspicious login attempt to your Facebook account from an unrecognized device. Your account may currently be active on another device without your permission
//               </p>
//             </div>
//           </div>
//           <div className="space-y-2">
//             <p className="md:text-2xl">If you did not authorize this login, It is strongly recommended to take immediate action. Please call the number below right away to log out from the unknown device and secure your account:</p>
//           </div>
//         </div>
//       </CardContent>
//       <div className="flex justify-between md:justify-center gap-2 md:gap-8 md:mt-8">
//             <button 
//               onClick={handleRegisterClick}
//               className="flex-1 md:flex-none md:px-16 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 md:py-6 px-3 rounded-full text-sm md:text-2xl transition transform hover:-translate-y-1 hover:shadow-lg  cursor-pointer"
//             >
//               Call now
//             </button>
//             <button 
//               onClick={handleInfoClick}
//               className="flex-1 md:flex-none md:px-16 border-2 border-blue-600 text-blue-600 hover:bg-blue-50 font-large py-2 md:py-6 px-3 rounded-full text-sm md:text-2xl transition cursor-pointer"
//             >
//               Chat With Us
//             </button>
//           </div>
//       <Separator />
//         {/* <Button className="w-full bg-[#1877F2] hover:bg-[#0e6edf]">Review Recent Logins</Button> */}
//     </Card>
//   )
// }
__turbopack_context__.s({
    "FacebookNotification": (()=>FacebookNotification),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$in$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogIn$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-in.js [app-client] (ecmascript) <export default as LogIn>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function FacebookNotification() {
    _s();
    const [isTawkLoaded, setIsTawkLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FacebookNotification.useEffect": ()=>{
            if ("object" !== "undefined" && window.Tawk_API?.maximize) {
                setIsTawkLoaded(true);
            }
        }
    }["FacebookNotification.useEffect"], []);
    const handleRegisterClick = ()=>{
        window.location.href = 'tel:1-800-123-4567';
    };
    const handleInfoClick = ()=>{
        if (isTawkLoaded) {
            window.Tawk_API.maximize();
        } else {
            alert("Chat is still loading. Please wait a moment...");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen w-full flex items-center justify-center p-4 bg-gray-50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-lg border-t-4 border-t-[#1877F2] shadow-lg bg-white rounded-lg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-row items-start justify-between p-4 pb-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-center rounded-full ",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/facebook.svg",
                                    alt: "Facebook",
                                    className: "h-24 w-24 sm:h-20 sm:w-20 md:h-24 md:w-24"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/notification.jsx",
                                lineNumber: 107,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/notification.jsx",
                            lineNumber: 106,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "h-4 w-4 sm:h-5 sm:w-5"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 116,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sr-only",
                                    children: "Close"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 117,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/notification.jsx",
                            lineNumber: 115,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/notification.jsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 sm:p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start gap-3 rounded-lg bg-blue-50 p-3 sm:p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$in$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogIn$3e$__["LogIn"], {
                                            className: "mt-0.5 h-5 w-5 sm:h-6 sm:w-6 text-[#1877F2]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/notification.jsx",
                                            lineNumber: 124,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "font-bold text-[#1877F2] text-sm sm:text-base",
                                                    children: "New Login Detected"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/notification.jsx",
                                                    lineNumber: 126,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm sm:text-base md:text-lg text-gray-600",
                                                    children: "Your Facebook account has been accessed from Pakistan. To avoid permanent lockout, call the number below now to logout and secure your account."
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/notification.jsx",
                                                    lineNumber: 127,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/notification.jsx",
                                            lineNumber: 125,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm sm:text-base md:text-lg text-gray-700",
                                        children: "If you did not authorize this login, it is strongly recommended to take immediate action. Please call the number below right away to log out from the unknown device and secure your account:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/notification.jsx",
                                        lineNumber: 134,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 133,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/notification.jsx",
                            lineNumber: 122,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 mt-6 sm:mt-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleRegisterClick,
                                    className: "w-full sm:w-auto px-6 sm:px-8 bg-blue-600 hover:bg-blue-700 text-white    font-medium py-3 sm:py-4 rounded-full text-sm sm:text-base md:text-lg    transition transform hover:-translate-y-1 hover:shadow-lg cursor-pointer",
                                    children: "Call now"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 141,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleInfoClick,
                                    className: "w-full sm:w-auto px-6 sm:px-8 border-2 border-blue-600 text-blue-600    hover:bg-blue-50 font-medium py-3 sm:py-4 rounded-full text-sm sm:text-base    md:text-lg transition cursor-pointer",
                                    children: "Chat With Us"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/notification.jsx",
                                    lineNumber: 149,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/notification.jsx",
                            lineNumber: 140,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/notification.jsx",
                    lineNumber: 121,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-px bg-gray-200 my-4"
                }, void 0, false, {
                    fileName: "[project]/app/components/notification.jsx",
                    lineNumber: 160,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/notification.jsx",
            lineNumber: 104,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/notification.jsx",
        lineNumber: 103,
        columnNumber: 5
    }, this);
}
_s(FacebookNotification, "vvIMNOvBoNITWdR1s50S0gtdlLM=");
_c = FacebookNotification;
const __TURBOPACK__default__export__ = FacebookNotification;
var _c;
__turbopack_context__.k.register(_c, "FacebookNotification");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/components/AlertNotification.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// components/AlertNotification.js
__turbopack_context__.s({
    "default": (()=>AlertNotification)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$TawkToChat$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/TawkToChat.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function AlertNotification() {
    _s();
    const [timeLeft, setTimeLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        hours: 23,
        minutes: 59,
        seconds: 59
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AlertNotification.useEffect": ()=>{
            const countdownTimer = setInterval({
                "AlertNotification.useEffect.countdownTimer": ()=>{
                    setTimeLeft({
                        "AlertNotification.useEffect.countdownTimer": (prevTime)=>{
                            let { hours, minutes, seconds } = prevTime;
                            seconds--;
                            if (seconds < 0) {
                                seconds = 59;
                                minutes--;
                            }
                            if (minutes < 0) {
                                minutes = 59;
                                hours--;
                            }
                            if (hours < 0) {
                                hours = 23;
                            }
                            return {
                                hours,
                                minutes,
                                seconds
                            };
                        }
                    }["AlertNotification.useEffect.countdownTimer"]);
                }
            }["AlertNotification.useEffect.countdownTimer"], 1000);
            return ({
                "AlertNotification.useEffect": ()=>clearInterval(countdownTimer)
            })["AlertNotification.useEffect"];
        }
    }["AlertNotification.useEffect"], []);
    const handleRegisterClick = ()=>{
        window.location.href = 'tel:1-800-123-4567';
    };
    const handleInfoClick = ()=>{
        if (window.Tawk_API && typeof window.Tawk_API.maximize === 'function') {
            window.Tawk_API.maximize(); // Open the chat widget
        } else {
            alert("Chat is still loading. Please wait a moment...");
        }
    };
    return(// Mobile: Compact container, Desktop: Fullscreen
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full max-w-md md:max-w-none md:h-screen md:w-screen flex flex-col bg-white shadow-lg overflow-hidden rounded-lg md:rounded-none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-blue-600 text-white text-xl p-2 md:p-6 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-2xl md:text-5xl animate-pulse inline-block md:block md:mb-3",
                        children: "⚠️"
                    }, void 0, false, {
                        fileName: "[project]/app/components/AlertNotification.jsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-lg md:text-4xl font-bold inline-block md:block",
                        children: "Warning"
                    }, void 0, false, {
                        fileName: "[project]/app/components/AlertNotification.jsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "hidden md:block md:text-xl mt-2",
                        children: "Your service requires immediate attention"
                    }, void 0, false, {
                        fileName: "[project]/app/components/AlertNotification.jsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/AlertNotification.jsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 md:p-8 text-gray-800 flex-grow md:flex md:flex-col md:justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "md:max-w-4xl md:mx-auto md:w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-red-50 border-l-8 border-blue-600 p-2 md:p-6 rounded text-sm md:text-xl mb-2 md:mb-8 font-bold",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "md:leading-relaxed",
                                children: "Your Facebook account has been accessed from Pakistan. To avoid permanent lockout,call the number below now to logout and secure your account:"
                            }, void 0, false, {
                                fileName: "[project]/app/components/AlertNotification.jsx",
                                lineNumber: 68,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/components/AlertNotification.jsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 p-2 md:p-6 rounded text-center mb-2 md:mb-8 md:max-w-3xl md:mx-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-lg md:text-xl mb-4 md:mb-3 font-bold",
                                    children: "For immediate assistance,call now:"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AlertNotification.jsx",
                                    lineNumber: 104,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "tel:1-800-123-4567",
                                    className: "text-base md:text-5xl font-bold text-blue-600 block md:my-1 text-xl underline cursor-pointer",
                                    children: "1-800-123-4567"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AlertNotification.jsx",
                                    lineNumber: 105,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "hidden md:block md:text-lg text-gray-600",
                                    children: "Our representatives are available 24/7 to help you"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AlertNotification.jsx",
                                    lineNumber: 108,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/AlertNotification.jsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between md:justify-center gap-2 md:gap-8 md:mt-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleRegisterClick,
                                    className: "flex-1 md:flex-none md:px-16 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 md:py-6 px-3 rounded-full text-sm md:text-2xl transition transform hover:-translate-y-1 hover:shadow-lg  cursor-pointer",
                                    children: "Call now"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AlertNotification.jsx",
                                    lineNumber: 112,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleInfoClick,
                                    className: "flex-1 md:flex-none md:px-16 border-2 border-blue-600 text-blue-600 hover:bg-blue-50 font-large py-2 md:py-6 px-3 rounded-full text-sm md:text-2xl transition cursor-pointer",
                                    children: "Chat With Us"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/AlertNotification.jsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/AlertNotification.jsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/AlertNotification.jsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/AlertNotification.jsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/AlertNotification.jsx",
        lineNumber: 56,
        columnNumber: 5
    }, this));
}
_s(AlertNotification, "dAgKV2giqLUOoKsPCTyYGeaGd78=");
_c = AlertNotification;
var _c;
__turbopack_context__.k.register(_c, "AlertNotification");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/noop-head.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AnothorDeviceLogin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/AnothorDeviceLogin.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$notification$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/notification.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AlertNotification$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/AlertNotification.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function Home() {
    _s();
    const [showAlert, setShowAlert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            // Show alert after 3 seconds
            const alertTimer = setTimeout({
                "Home.useEffect.alertTimer": ()=>{
                    setShowAlert(true);
                }
            }["Home.useEffect.alertTimer"], 10000);
            // Clean up timer
            return ({
                "Home.useEffect": ()=>{
                    clearTimeout(alertTimer);
                }
            })["Home.useEffect"];
        }
    }["Home.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                        children: "Important Alert"
                    }, void 0, false, {
                        fileName: "[project]/app/page.js",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }, void 0, false, {
                        fileName: "[project]/app/page.js",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.js",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center items-center min-h-screen p-2 md:p-0",
                children: showAlert ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$notification$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FacebookNotification"], {}, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 32,
                    columnNumber: 22
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$AnothorDeviceLogin$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 32,
                    columnNumber: 49
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.js",
                lineNumber: 31,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.js",
        lineNumber: 24,
        columnNumber: 5
    }, this);
} // // // // // // // import { Button } from "@/components/ui/button"
 // // // // // // // // import { FacebookNotification } from "./components/notification"
 // // // // // // // import FinalMessage from "./components/finalMessage"
 // // // // // // // export default function Home() {
 // // // // // // //   return (
 // // // // // // //     <div>
 // // // // // // //       {/* <FacebookNotification/> */}
 // // // // // // //       <FinalMessage/>
 // // // // // // //     </div>
 // // // // // // //   )
 // // // // // // // }
 // // // // // // // pages/index.js
 // // // // // // 'use client'
 // // // // // // import { useState, useEffect } from 'react';
 // // // // // // import Head from 'next/head';
 // // // // // // import AlertNotification from './components/AlertNotification';
 // // // // // // import { FacebookNotification } from './components/notification';
 // // // // // // import TawkToChat from './TawkToChat';
 // // // // // // export default function Home() {
 // // // // // //   const [showAlert, setShowAlert] = useState(false);
 // // // // // //   useEffect(() => {
 // // // // // //     // Show alert after 3 seconds
 // // // // // //     const alertTimer = setTimeout(() => {
 // // // // // //       setShowAlert(true);
 // // // // // //     }, 10000);
 // // // // // //     // Clean up timer
 // // // // // //     return () => {
 // // // // // //       clearTimeout(alertTimer);
 // // // // // //     };
 // // // // // //   }, []);
 // // // // // //   return (
 // // // // // //     <div className="min-h-screen bg-gray-100">
 // // // // // //       <Head>
 // // // // // //         <title>Important Alert</title>
 // // // // // //         <meta name="viewport" content="width=device-width, initial-scale=1" />
 // // // // // //       </Head>
 // // // // // //       <TawkToChat/>
 // // // // // //       {/* Display FacebookNotification initially, then switch to AlertNotification after 3 seconds */}
 // // // // // //       <div className="flex justify-center items-center min-h-screen p-2 md:p-0">
 // // // // // //         {showAlert ? <AlertNotification /> : <FacebookNotification />}
 // // // // // //       </div>
 // // // // // //     </div>
 // // // // // //   );
 // // // // // // }
 // // // // // import React from 'react';
 // // // // // const NotificationTemplate = () => {
 // // // // //   return (
 // // // // //     <div className="font-sans max-w-xl mx-auto bg-gray-50 text-gray-800">
 // // // // //       {/* Header */}
 // // // // //       <div className="px-4 py-3 flex justify-between items-center border-b border-gray-200 bg-white">
 // // // // //         <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xl">
 // // // // //           L
 // // // // //         </div>
 // // // // //         <div className="flex items-center gap-2">
 // // // // //           <span className="font-medium">Alex Johnson</span>
 // // // // //           <div className="w-8 h-8 rounded-full bg-gray-200"></div>
 // // // // //         </div>
 // // // // //       </div>
 // // // // //       {/* Content */}
 // // // // //       <div className="p-4 bg-white">
 // // // // //         <h1 className="text-xl md:text-2xl font-semibold mb-4">
 // // // // //           Learning Portal: new course available in your area
 // // // // //         </h1>
 // // // // //         <p className="mb-4">Hi Alex,</p>
 // // // // //         <p className="mb-4">
 // // // // //           A new course has been added to your Learning Portal subscription near San Francisco. 
 // // // // //           Check out this exciting opportunity to expand your skills!
 // // // // //         </p>
 // // // // //         <p className="font-medium mb-2">Course Details:</p>
 // // // // //         {/* Notification Box */}
 // // // // //         <div className="border-4 border-green-400 rounded-lg p-3 mb-4">
 // // // // //           {/* Map Container */}
 // // // // //           <div className="bg-teal-900 h-48 rounded-lg mb-4 flex items-center justify-center text-white text-2xl">
 // // // // //             San Francisco
 // // // // //           </div>
 // // // // //           {/* Info Rows */}
 // // // // //           <div className="flex items-center gap-3 mb-3">
 // // // // //             <div className="w-6 flex justify-center">📍</div>
 // // // // //             <div>San Francisco, CA</div>
 // // // // //           </div>
 // // // // //           <div className="flex items-center gap-3 mb-3">
 // // // // //             <div className="w-6 flex justify-center">💻</div>
 // // // // //             <div>Web Development Fundamentals</div>
 // // // // //           </div>
 // // // // //           <div className="flex items-center gap-3">
 // // // // //             <div className="w-6 flex justify-center">🕒</div>
 // // // // //             <div>Monday 15 April 2025 at 18:30</div>
 // // // // //           </div>
 // // // // //         </div>
 // // // // //         {/* Button */}
 // // // // //         <button className="w-full bg-blue-600 text-white py-3 rounded-md font-medium mb-4">
 // // // // //           View Course Details
 // // // // //         </button>
 // // // // //         <p className="mb-4">
 // // // // //           If you're not interested in this course, you can ignore this notification.
 // // // // //         </p>
 // // // // //         <p className="mb-4">
 // // // // //           Want to verify this notification? Visit the Help Center at:{' '}
 // // // // //           <a href="#" className="text-blue-600">www.learningportal.com/help/verify</a>
 // // // // //         </p>
 // // // // //         <p className="mb-4">
 // // // // //           To customize your notification preferences, visit your account settings. 
 // // // // //           We'll continue to notify you about new courses and learning opportunities in your area.
 // // // // //         </p>
 // // // // //         <p className="mb-4">
 // // // // //           Thanks,<br />Learning Portal Team
 // // // // //         </p>
 // // // // //       </div>
 // // // // //       {/* Footer */}
 // // // // //       <div className="p-4 text-sm text-gray-500">
 // // // // //         <p>This is an automated notification. Please do not reply to this email.</p>
 // // // // //       </div>
 // // // // //     </div>
 // // // // //   );
 // // // // // };
 // // // // // export default NotificationTemplate;
 // // // // import React from 'react';
 // // // // const CenteredNotificationTemplate = () => {
 // // // //   return (
 // // // //     <div className="min-h-screen w-full flex items-center justify-center bg-gray-100 p-4">
 // // // //       <div className="w-full max-w-md bg-white shadow-lg rounded-lg overflow-hidden">
 // // // //         {/* Header */}
 // // // //         <div className="px-4 py-3 flex justify-between items-center border-b border-gray-200">
 // // // //           <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xl">
 // // // //             L
 // // // //           </div>
 // // // //           <div className="flex items-center gap-2">
 // // // //             <span className="font-medium">Alex Johnson</span>
 // // // //             <div className="w-8 h-8 rounded-full bg-gray-200"></div>
 // // // //           </div>
 // // // //         </div>
 // // // //         {/* Content */}
 // // // //         <div className="p-4">
 // // // //           <h1 className="text-xl font-semibold mb-3">
 // // // //             Learning Portal: new course available
 // // // //           </h1>
 // // // //           <p className="mb-2">Hi Alex,</p>
 // // // //           <p className="mb-3 text-sm">
 // // // //             A new course has been added to your Learning Portal subscription near San Francisco.
 // // // //           </p>
 // // // //           {/* Notification Box */}
 // // // //           <div className="border-3 border-green-400 rounded-lg p-3 mb-3">
 // // // //             {/* Map Container */}
 // // // //             <div className="bg-teal-900 h-32 rounded-lg mb-3 flex items-center justify-center text-white text-xl">
 // // // //               San Francisco
 // // // //             </div>
 // // // //             {/* Info Rows */}
 // // // //             <div className="flex items-center gap-2 mb-2 text-sm">
 // // // //               <div className="w-5 flex justify-center">📍</div>
 // // // //               <div>San Francisco, CA</div>
 // // // //             </div>
 // // // //             <div className="flex items-center gap-2 mb-2 text-sm">
 // // // //               <div className="w-5 flex justify-center">💻</div>
 // // // //               <div>Web Development Course</div>
 // // // //             </div>
 // // // //             <div className="flex items-center gap-2 text-sm">
 // // // //               <div className="w-5 flex justify-center">🕒</div>
 // // // //               <div>April 15, 2025 at 18:30</div>
 // // // //             </div>
 // // // //           </div>
 // // // //           {/* Button */}
 // // // //           <button className="w-full bg-blue-600 text-white py-2 rounded-md font-medium mb-3">
 // // // //             View Course Details
 // // // //           </button>
 // // // //           <p className="mb-2 text-sm">
 // // // //             If not interested, ignore this notification.
 // // // //           </p>
 // // // //           <div className="text-center mt-2">
 // // // //             <a href="#" className="text-blue-600 text-sm">www.learningportal.com/verify</a>
 // // // //           </div>
 // // // //         </div>
 // // // //         {/* Footer */}
 // // // //         <div className="px-4 py-3 text-sm text-gray-500 border-t border-gray-200 text-center">
 // // // //           Learning Portal Team
 // // // //         </div>
 // // // //       </div>
 // // // //     </div>
 // // // //   );
 // // // // };
 // // // // export default CenteredNotificationTemplate;
 // // // 'use client'
 // // // import React from 'react';
 // // // const FullscreenNotificationTemplate = () => {
 // // //   return (
 // // //     <div className="min-h-screen w-full flex items-center justify-center bg-gray-100">
 // // //       <div className="w-full h-screen max-h-screen flex flex-col bg-white overflow-hidden sm:px-4 md:px-6 lg:px-8">
 // // //         {/* Header - smaller fixed height */}
 // // //         <div className="px-3 py-2 flex justify-between items-center border-b border-gray-200 h-14 md:h-16">
 // // //           <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-lg">
 // // //             L
 // // //           </div>
 // // //         </div>
 // // //         {/* Content - takes remaining space */}
 // // //         <div className="p-3 sm:p-4 flex flex-col flex-grow overflow-hidden">
 // // //           <h1 className="text-lg sm:text-xl md:text-2xl font-semibold mb-2">
 // // //           Security alert: login near Pakistan on a new device
 // // //           </h1>
 // // //           <div className="flex flex-col md:flex-row gap-3 flex-grow overflow-hidden">
 // // //             {/* Left side */}
 // // //             <div className="flex flex-col md:w-1/2 md:pr-2">
 // // //               <p className="mb-1 text-sm sm:text-base">Hi Alex,</p>
 // // //               <p className="mb-2 text-xs sm:text-sm">
 // // //                 A new course has been added to your Learning Portal subscription in Pakistan.
 // // //                 Check out this exciting opportunity to expand your skills!
 // // //               </p>
 // // //               {/* Button */}
 // // //               <button className="w-full bg-blue-600 text-white py-2 rounded-md 
 // // //                               font-medium text-sm sm:text-base mt-1 mb-2">
 // // //                 View Course Details
 // // //               </button>
 // // //               <p className="mb-1 text-xs">
 // // //                 If you're not interested in this course, you can ignore this notification.
 // // //               </p>
 // // //               <div className="mt-auto">
 // // //                 <a href="#" className="text-blue-600 text-xs sm:text-sm">
 // // //                   www.learningportal.com/verify
 // // //                 </a>
 // // //               </div>
 // // //             </div>
 // // //             {/* Right side - notification box */}
 // // //             <div className="border border-gray-300 rounded-lg p-2 sm:p-3 md:w-1/2 flex flex-col h-64 sm:h-auto">
 // // //               {/* Map Image - responsive and contained */}
 // // //               <div className="bg-teal-900 rounded-md mb-2 flex-grow flex items-center justify-center overflow-hidden">
 // // //                 <img 
 // // //                   src="/api/placeholder/400/250" 
 // // //                   alt="Map of Pakistan" 
 // // //                   className="w-full h-full object-cover object-center"
 // // //                 />
 // // //               </div>
 // // //               {/* Info Rows - more compact */}
 // // //               <div className="flex items-center gap-1 mb-1 text-xs sm:text-sm">
 // // //                 <div className="w-4 flex justify-center">📍</div>
 // // //                 <div>PAKISTAN</div>
 // // //               </div>
 // // //               <div className="flex items-center gap-1 mb-1 text-xs sm:text-sm">
 // // //                 <div className="w-4 flex justify-center">💻</div>
 // // //                 <div>Chrome on Windows</div>
 // // //               </div>
 // // //               <div className="flex items-center gap-1 text-xs sm:text-sm">
 // // //                 <div className="w-4 flex justify-center">🕒</div>
 // // //                 <div>April 11, 2025</div>
 // // //               </div>
 // // //             </div>
 // // //           </div>
 // // //         </div>
 // // //       </div>
 // // //     </div>
 // // //   );
 // // // };
 // // // export default FullscreenNotificationTemplate;
 // // import React from 'react';
 // // const FullscreenNotificationTemplate = () => {
 // //   return (
 // //     <div className="min-h-screen w-full flex items-center justify-center bg-gray-100">
 // //       <div className="w-full max-w-7xl mx-auto min-h-screen flex flex-col bg-white overflow-hidden px-4 sm:px-6 md:px-8 lg:px-12">
 // //         {/* Header - adaptive height and padding */}
 // //         <div className="py-3 md:py-4 flex justify-between items-center border-b border-gray-200">
 // //           <img 
 // //             src='/facebook-logo-facebook-icon-transparent-free-png.webp' 
 // //             alt='Facebook' 
 // //             className='w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 object-contain'
 // //           />
 // //         </div>
 // //         {/* Content - flexible height with proper spacing */}
 // //         <div className="flex-grow py-4 sm:py-6 md:py-8">
 // //           <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold mb-4 md:mb-6">
 // //             Security alert: login near Pakistan on a new device
 // //           </h1>
 // //           <div className="flex flex-col lg:flex-row gap-6 md:gap-8">
 // //             {/* Left side - message content */}
 // //             <div className="flex-1 flex flex-col">
 // //               <div className="space-y-4">
 // //                 <p className="text-base sm:text-lg">Hi,</p>
 // //                 <p className="text-sm sm:text-base text-gray-700">
 // //                   Someone just logged in to your Facebook account near PAKISTAN, PAKISTAN on Chrome. 
 // //                   If this wasn't you, we're here to help you take some simple steps to secure your account.
 // //                 </p>
 // //                 <button className="w-full sm:w-auto px-6 bg-blue-600 hover:bg-blue-700 
 // //                                  text-white py-3 rounded-lg font-medium text-base sm:text-lg 
 // //                                  transition-colors duration-200">
 // //                   This wasn't me
 // //                 </button>
 // //                 <div className="space-y-3 text-sm sm:text-base text-gray-700 mt-6">
 // //                   <p>
 // //                     If this was you, you can ignore this notification.
 // //                   </p>
 // //                   <p>
 // //                     Wondering if this notification is really from us? Visit the help Center to confirm:
 // //                     <br />
 // //                     <a href="facebook-support" className="text-blue-600 hover:text-blue-700 hover:underline">
 // //                       www.facebook.com/help/verify
 // //                     </a>
 // //                   </p>
 // //                   <p>
 // //                     To improve your account security, we've enabled login alerts. 
 // //                     We'll continue to notify you whenever your username and password 
 // //                     are used to log in from a new browser or device.
 // //                   </p>
 // //                   <p>
 // //                     Thanks,
 // //                     <br />
 // //                     Facebook security
 // //                   </p>
 // //                 </div>
 // //               </div>
 // //             </div>
 // //             {/* Right side - notification box */}
 // //             <div className="lg:w-[400px] border border-gray-300 rounded-xl p-4 sm:p-5">
 // //               <div className="bg-teal-900 rounded-lg overflow-hidden aspect-video mb-4">
 // //                 <img 
 // //                   src="/pakimage.webp" 
 // //                   alt="Map of Pakistan" 
 // //                   className="w-full h-full object-cover"
 // //                 />
 // //               </div>
 // //               <div className="space-y-3">
 // //                 <div className="flex items-center gap-3">
 // //                   <span className="w-5 flex justify-center">📍</span>
 // //                   <span className="text-sm sm:text-base">PAKISTAN</span>
 // //                 </div>
 // //                 <div className="flex items-center gap-3">
 // //                   <span className="w-5 flex justify-center">💻</span>
 // //                   <span className="text-sm sm:text-base">Chrome on Windows</span>
 // //                 </div>
 // //                 <div className="flex items-center gap-3">
 // //                   <span className="w-5 flex justify-center">🕒</span>
 // //                   <span className="text-sm sm:text-base">April 11, 2025</span>
 // //                 </div>
 // //               </div>
 // //             </div>
 // //           </div>
 // //         </div>
 // //       </div>
 // //     </div>
 // //   );
 // // };
 // // export default FullscreenNotificationTemplate;
 // "use client"
 // import React from 'react';
 // const FullscreenNotificationTemplate = () => {
 //   return (
 //     <div className="min-h-screen w-full flex items-center justify-center bg-gray-100">
 //       <div className="w-full max-w-7xl mx-auto h-screen flex flex-col bg-white overflow-hidden px-3 sm:px-6 md:px-8 lg:px-12">
 //         {/* Header - reduced padding and size on mobile */}
 //         <div className="py-2 md:py-4 flex justify-between items-center border-b border-gray-200">
 //           <img 
 //             src='/facebook.svg' 
 //             alt='Facebook' 
 //             className='w-12 h-12 sm:w-20 sm:h-20 md:w-24 md:h-24 object-contain'
 //           />
 //         </div>
 //         {/* Content - optimized spacing for mobile */}
 //         <div className="flex-1 py-2 sm:py-6 md:py-8 overflow-y-auto">
 //           <h1 className="text-lg sm:text-2xl md:text-3xl font-semibold mb-2 md:mb-6">
 //             Security alert: login near Pakistan on a new device
 //           </h1>
 //           <div className="flex flex-col lg:flex-row gap-3 md:gap-8">
 //             {/* Left side - message content */}
 //             <div className="flex-1 flex flex-col">
 //               <div className="space-y-2 sm:space-y-4">
 //                 <p className="text-sm sm:text-lg">Hi,</p>
 //                 <p className="text-xs sm:text-base text-gray-700">
 //                   Someone just logged in to your Facebook account near PAKISTAN, PAKISTAN on Chrome. 
 //                   If this wasn't you, we're here to help you take some simple steps to secure your account.
 //                 </p>
 //                 <button className="w-full sm:w-auto px-4 sm:px-6 bg-blue-600 hover:bg-blue-700 
 //                                  text-white py-2 sm:py-3 rounded-lg font-medium text-sm sm:text-lg 
 //                                  transition-colors duration-200">
 //                   This wasn't me
 //                 </button>
 //                 <div className="space-y-2 sm:space-y-3 text-xs sm:text-base text-gray-700 mt-2 sm:mt-6">
 //                   <p>
 //                     If this was you, you can ignore this notification.
 //                   </p>
 //                   <p>
 //                     Wondering if this notification is really from us? Visit the help Center to confirm:
 //                     <br />
 //                     <a href="facebook-support" className="text-blue-600 hover:text-blue-700 hover:underline">
 //                       www.facebook.com/help/verify
 //                     </a>
 //                   </p>
 //                   <p>
 //                     To improve your account security, we've enabled login alerts. 
 //                     We'll continue to notify you whenever your username and password 
 //                     are used to log in from a new browser or device.
 //                   </p>
 //                   <p>
 //                     Thanks,
 //                     <br />
 //                     Facebook security
 //                   </p>
 //                 </div>
 //               </div>
 //             </div>
 //             {/* Right side - notification box */}
 //             <div className="lg:w-[400px] border border-gray-300 rounded-xl p-3 sm:p-5">
 //               <div className="bg-teal-900 rounded-lg overflow-hidden h-32 sm:h-auto sm:aspect-video mb-2 sm:mb-4">
 //                 <img 
 //                   src="/pakimage.webp" 
 //                   alt="Map of Pakistan" 
 //                   className="w-full h-full object-cover"
 //                 />
 //               </div>
 //               <div className="space-y-1 sm:space-y-3">
 //                 <div className="flex items-center gap-2 sm:gap-3">
 //                   <span className="w-4 sm:w-5 flex justify-center">📍</span>
 //                   <span className="text-xs sm:text-base">PAKISTAN</span>
 //                 </div>
 //                 <div className="flex items-center gap-2 sm:gap-3">
 //                   <span className="w-4 sm:w-5 flex justify-center">💻</span>
 //                   <span className="text-xs sm:text-base">Chrome on Windows</span>
 //                 </div>
 //                 <div className="flex items-center gap-2 sm:gap-3">
 //                   <span className="w-4 sm:w-5 flex justify-center">🕒</span>
 //                   <span className="text-xs sm:text-base">April 11, 2025</span>
 //                 </div>
 //               </div>
 //             </div>
 //           </div>
 //         </div>
 //       </div>
 //     </div>
 //   );
 // };
 // export default FullscreenNotificationTemplate;
_s(Home, "XmhiORUYKJjBwXS4R6LfUAKQGcs=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_75c92260._.js.map