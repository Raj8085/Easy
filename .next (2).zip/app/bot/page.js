export default function BotPage() {
    return (
        <div>
            <h1>Hello world</h1>
        </div>
    );
}